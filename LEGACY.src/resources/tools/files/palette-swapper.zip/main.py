import os
import sys
import colorama
from PIL import Image

colorama.init()

def check_file(path):
    if not os.path.isfile(path):
        print(f"{colorama.Fore.RED}Error: No file at {colorama.Fore.YELLOW}\"{path}\"")
        exit()

if len(sys.argv) < 5:
    print(f"{colorama.Fore.RED}Error: invalid script use")
    print(f"{colorama.Fore.YELLOW}Usage: <src_img_path> <src_palette_path> <palette_path> <output_path> [alpha]")
    exit()

src_img_path = sys.argv[1]
src_palette_path = sys.argv[2]
palette_path = sys.argv[3]
output_path = sys.argv[4]
alpha = 255

if len(sys.argv) >= 6:
    alpha = int(sys.argv[5])

check_file(src_img_path)
check_file(src_palette_path)
check_file(palette_path)

src_palette_img = Image.open(src_palette_path)
palette_img = Image.open(palette_path)
src_img = Image.open(src_img_path)
output_img = src_img.copy()

if palette_img.width < src_palette_img.width or palette_img.height < src_palette_img.height:
    print(f"{colorama.Fore.RED}Error: Palette image is smaller than source palette image")
    print(f"{colorama.Fore.YELLOW}Palette image size: ({palette_img.width}, {palette_img.height})")
    print(f"{colorama.Fore.YELLOW}Source palette image size: ({src_palette_img.width}, {src_palette_img.height})")
    exit()

src_palette = []
palette = []

for x in range(src_palette_img.width):
    for y in range(src_palette_img.height):
        src_pixel = src_palette_img.getpixel((x, y))
        if not src_pixel in src_palette: 
            src_palette.append(src_pixel)
            palette.append(palette_img.getpixel((x, y)))

for x in range(src_img.width):
    for y in range(src_img.height):
        pixel = src_img.getpixel((x, y))
        if not pixel in src_palette: continue
        i = src_palette.index(pixel)

        output_img.putpixel((x, y), (palette[i][0], palette[i][1], palette[i][2], alpha))

output_dir = output_path.removesuffix(output_path.split("/")[-1])
if not os.path.isdir(output_dir):
    os.makedirs(output_dir)

output_img.save(output_path)

src_palette_img.close()
palette_img.close()
src_img.close()
output_img.close()

print(f"{colorama.Fore.LIGHTGREEN_EX}Succeded converting \"{output_path}\"")